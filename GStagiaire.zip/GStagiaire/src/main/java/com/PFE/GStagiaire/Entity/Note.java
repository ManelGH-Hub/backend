package com.PFE.GStagiaire.Entity;




import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Note {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String week;

    private String encadrantNote;

    private String stagiaireNote;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getWeek() {
		return week;
	}

	public void setWeek(String week) {
		this.week = week;
	}

	public String getEncadrantNote() {
		return encadrantNote;
	}

	public void setEncadrantNote(String encadrantNote) {
		this.encadrantNote = encadrantNote;
	}

	public String getStagiaireNote() {
		return stagiaireNote;
	}

	public void setStagiaireNote(String stagiaireNote) {
		this.stagiaireNote = stagiaireNote;
	}

    // Getters and setters
}
