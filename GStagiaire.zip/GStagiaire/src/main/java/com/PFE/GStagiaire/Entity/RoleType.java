 package com.PFE.GStagiaire.Entity;

public enum RoleType {
    ADMIN,
    STAGIAIRE,
    ENCADRANT
}
