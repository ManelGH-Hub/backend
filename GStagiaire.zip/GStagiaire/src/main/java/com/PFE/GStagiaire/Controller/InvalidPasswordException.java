package com.PFE.GStagiaire.Controller;

public class InvalidPasswordException {

	public Object getMessage() {
		// TODO Auto-generated method stub
		return null;
	}

}
