package com.PFE.GStagiaire.Entity;


import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Suivi {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String semaine;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date date;
    
    private boolean present;
    
    private boolean absent;
    
    private boolean vacance;
    @ManyToOne
    private User user;

    // Constructeurs, getters et setters

    public Suivi() {
    }

    public Suivi(String semaine, Date date, boolean present, boolean absent, boolean vacance) {
        this.semaine = semaine;
        this.date = date;
        this.present = present;
        this.absent = absent;
        this.vacance = vacance;
    }

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSemaine() {
        return semaine;
    }

    public void setSemaine(String semaine) {
        this.semaine = semaine;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public boolean isPresent() {
        return present;
    }

    public void setPresent(boolean present) {
        this.present = present;
    }

    public boolean isAbsent() {
        return absent;
    }

    public void setAbsent(boolean absent) {
        this.absent = absent;
    }

    public boolean isVacance() {
        return vacance;
    }

    public void setVacance(boolean vacance) {
        this.vacance = vacance;
    }
    public void setUser(User user) {
        this.user = user;
    }
    
    
    
    
}

