package com.PFE.GStagiaire.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.PFE.GStagiaire.Entity.Reunion;
import com.PFE.GStagiaire.Service.ReunionService;

import java.util.List;

@RestController
@RequestMapping("/api/reunions")
public class ReunionController {

    @Autowired
    private ReunionService reunionService;

    @PostMapping("")
    public Reunion createReunion(@RequestBody Reunion reunion) {
        return reunionService.createReunion(reunion);
    }

    @GetMapping("")
    public List<Reunion> getAllReunions() {
        return reunionService.getAllReunions();
    }
    
    @PutMapping("/{id}/update-status")
    public Reunion updateReunionStatus(@PathVariable Long id, @RequestBody String newStatus) {
        Reunion reunionToUpdate = reunionService.getReunionById(id);
        reunionToUpdate.setStatus(newStatus);
        return reunionService.updateReunion(reunionToUpdate);
    }


}
