package com.PFE.GStagiaire.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.PFE.GStagiaire.Entity.Note;
import com.PFE.GStagiaire.Service.NoteService;

import java.util.List;

@RestController
@RequestMapping("/api/notes")
public class NoteController {

    @Autowired
    private NoteService noteService;

    @GetMapping
    public ResponseEntity<List<Note>> getAllNotes() {
        List<Note> notes = noteService.getAllNotes();
        return new ResponseEntity<>(notes, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Note> createOrUpdateNote(@RequestBody Note note) {
        Note savedNote = noteService.createOrUpdateNote(note);
        return new ResponseEntity<>(savedNote, HttpStatus.CREATED);
    }

    // Other endpoints as needed
}
