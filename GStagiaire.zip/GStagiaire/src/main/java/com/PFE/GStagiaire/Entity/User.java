package com.PFE.GStagiaire.Entity;


import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;


@Entity
public class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    private String nom;
    private String prenom;
    private String CIN;
    private String TEL;
    private String login;
    private String password;
    private String etablissement;
    private String Niveau;
    private String filiere;
   
    
  @Enumerated(EnumType.STRING)
    private RoleType role;

    // Constructeur, getters et setters
  

    public User() {}

    public User(String nom, String prenom, String CIN, String TEL, String login, String password , RoleType role) {
        this.nom = nom;
        this.prenom = prenom;
        this.CIN = CIN;
        this.TEL = TEL;
        this.login = login;
        this.password = password;
        this.role = role;
        
    }

    // Getters and setters

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getCIN() {
        return CIN;
    }

    public void setCIN(String CIN) {
        this.CIN = CIN;
    }

    public String getTEL() {
        return TEL;
    }

    public void setTEL(String TEL) {
        this.TEL = TEL;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

	/*public boolean isPresent() {
		// TODO Auto-generated method stub
		return false;
	}
*/
	public RoleType getRole() {
		return role;
	}

	public void setRole(RoleType role) {
		this.role = role;
	}
	
	public String getEtablissement() {
		return etablissement;
	}

	public void setEtablissement(String etablissement) {
		this.etablissement = etablissement;
	}
	public String getNiveau() {
		return Niveau;
	}

	public void setNiveau(String Niveau) {
		this.Niveau = Niveau;
	}
	public String getFiliere() {
		return filiere;
	}

	public void setFiliere(String filiere) {
		this.filiere = filiere;
	}
    

}
