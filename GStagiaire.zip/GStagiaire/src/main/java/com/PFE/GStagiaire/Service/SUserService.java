package com.PFE.GStagiaire.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service 
public class SUserService {
	 @Autowired
	    private JavaMailSender emailSender;

	    @Value("${spring.mail.username}")
	    private String fromEmail;

	    public void sendForgotPasswordEmail(String toEmail, String newPassword) {
	        MimeMessage message = emailSender.createMimeMessage();
	        MimeMessageHelper helper = new MimeMessageHelper(message);
	        try {
	            helper.setFrom(fromEmail);
	            helper.setTo(toEmail);
	            helper.setSubject("Réinitialisation de mot de passe");
	            helper.setText("Votre nouveau mot de passe est : " + newPassword);
	            emailSender.send(message);
	        } catch (MessagingException e) {
	            e.printStackTrace();
	            // Gérer l'exception (par exemple, journalisation)
	        }
	    }
}
