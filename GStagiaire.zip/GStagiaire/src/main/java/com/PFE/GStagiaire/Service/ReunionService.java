package com.PFE.GStagiaire.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PFE.GStagiaire.Entity.Reunion;
import com.PFE.GStagiaire.Repository.ReunionsRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ReunionService {

    @Autowired
    private ReunionsRepository reunionRepository;

    public Reunion createReunion(Reunion reunion) {
        return reunionRepository.save(reunion);
    }

    public List<Reunion> getAllReunions() {
        return reunionRepository.findAll();
    }

    public Reunion updateReunion(Reunion reunionToUpdate) {
        return reunionRepository.save(reunionToUpdate);
    }

    public Reunion getReunionById(Long id) {
        Optional<Reunion> reunionOptional = reunionRepository.findById(id);
        return reunionOptional.orElse(null);
    }
}
