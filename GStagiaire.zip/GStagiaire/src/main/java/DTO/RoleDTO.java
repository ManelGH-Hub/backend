/*package DTO;

import com.PFE.GStagiaire.Entity.RoleType;

public class RoleDTO {
    private Long roleId;
    private RoleType name;
	public void setId(Long id2) {
		// TODO Auto-generated method stub
		
	}
	public void setname(String string) {
		// TODO Auto-generated method stub
		
	}
	/**
	 */
	/*public RoleDTO() {
		this.roleId = roleId;
		this.name = name;
	}

    // Getters and setters
}
*/